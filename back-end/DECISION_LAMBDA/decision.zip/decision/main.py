import json
import os
import time
from numpy import empty
import pandas as pd
import datetime
import boto3
import botocore
from botocore.exceptions import ClientError
from io import StringIO
from Data_handler import DBHandler







class ARS(object):

    def __init__(self, s3_resource, s3_client, absence_data, teams, employees, jobs, absence_type, rules):

        self.db = DBHandler(s3_resource, s3_client, absence_data, teams, employees, jobs, absence_type, rules)

        self.__rules = self.db.get_rules_by_keys()
        self.__rules_structs, self.__rules_df_sort = self.db.get_rules_with_order()

    def rule_overlapping_employees_no(self, request):
        '''
            returns number of overlapping employees with already accepted timeoffs with dates of given requests 
            optional: normalized, if set true, returns percentage of absent employees
                otherwise returns count of absent employees
        '''

        if request.empty:
            return None

        ou_absence_data = self.db.get_ou_absence_data(request)

        if(ou_absence_data.empty):
            return 0

        # format dates
        ou_absence_data = self.db.format_absence_dates(ou_absence_data)
        request_formatted = self.db.format_absence_dates(request.copy())

        # intialize empty set of overlapping days
        overlapping_days = set()

        # iterate over accepted timeoffs
        for _, absence_data in ou_absence_data.iterrows():
            # if employee has accepted timeoff in same day as new request, add the overlapping days to set "overlapping_days"
            request_range = [request_formatted["AbsenceFrom"], request_formatted["AbsenceTo"]]
            absence_data_range = [absence_data["AbsenceFrom"], absence_data["AbsenceTo"]]
            overlapping_days = overlapping_days.union(self.db.get_overlapping_days(*request_range) & self.db.get_overlapping_days(*absence_data_range))
              
        self.db.update_item(overlapping_days, request.name, "OverlappingDays", self.db.absence_data)

        return len(overlapping_days)


    def rule_min_capacity_threshold(self, request):
        '''
            returns if minimal OU capacity treshhold is exceeded
        '''
        min_ou_capacity = self.db.get_min_capacity_ou(request)
        size_of_ou = self.db.get_size_of_ou(request)
        total_missing_employees = self.rule_overlapping_employees_no(request)

        if size_of_ou - total_missing_employees <= min_ou_capacity:
            return 1
        else:
            return 0


    def rule_same_job_overlaps(self,request):
        '''
            returns number of overlapping employees with already accepted timeoffs with dates of given requests
            where same job employees are compared
            optional: normalized, if set true, returns percentage of absent employees with same job
                otherwise returns count of absent employees with same job
        '''
        if request.empty:
            return None

        same_job_absence_data = self.db.get_ou_same_job_absence(request)

        if(same_job_absence_data.empty):
            return 0

        #format dates
        same_job_absence_data = self.db.format_absence_dates(same_job_absence_data)
        request_formatted = self.db.format_absence_dates(request.copy())

        # intialize empty set of overlapping days
        overlapping_days = set()

        # iterate over accepted timeoffs
        for _, absence_data in same_job_absence_data.iterrows():
            # if employee has accepted timeoff in same day as new request, add the overlapping days to set "overlapping_days"
            request_range = [request_formatted["AbsenceFrom"], request_formatted["AbsenceTo"]]
            absence_data_range = [absence_data["AbsenceFrom"], absence_data["AbsenceTo"]]
            overlapping_days = overlapping_days.union(self.db.get_overlapping_days(*request_range) & self.db.get_overlapping_days(*absence_data_range))
            
        self.db.update_item(overlapping_days, request.name, "OverlappingDays", self.db.absence_data)

        return len(overlapping_days)



    def rule_min_same_job_threshold(self, request):
        '''
            returns if absent same job employees treshhold is exceeded
        '''
        min_same_job_tresh = self.db.get_min_same_job_threshold(request)
        same_job_employee_no = len(self.db.get_ou_same_job_employees(request, only_id=True))
        total_missing_employees = self.rule_same_job_overlaps(request)
        if same_job_employee_no - total_missing_employees <= min_same_job_tresh:
            return 1
        else:
            return 0

    def rule_set_absence_type_priority(self, request):
        '''
            returns absent type priority of given request
        '''
        return self.db.get_absence_type_priority(request) 


    def rule_leave_balance(self, request):
        '''
            returns absent type priority of given request
        '''
        if request["AbsenceTypeCode"] == "TIM":
            has_enough_leave_balance = self.db.check_enough_leave_balance(request)
            # if TIMEOFF and enough leave balance return that leave balance
            if has_enough_leave_balance:
                return self.db.get_employee_info(request, info = "LeaveBalance")
            # return 0 if not enough leave balance
            else:
                return 0
        # if not TIMEOFF return 1 to not to trigger balance rule (PARENTAL or SPECIAL)
        else:
            return 1
        

    def rating_function(self, request):
        '''
            rate all pending requests based on rules specified in rules priority
            saves ratings in dataframe
        '''
        # get all OU pending requests
        ou_pending_requests = self.db.get_ou_absence_data(request, status_of_absence="Pending")
        ou_pending_requests['AbsenceTypeCode'] = pd.Categorical(ou_pending_requests['AbsenceTypeCode'], ["SPE", "PAR", "TIM"])
        ou_pending_requests = ou_pending_requests.sort_values(by =["AbsenceTypeCode"]) # , "AbsenceRequestedAt"])  <-- to be discussed ! 
        # iterate over those requests
        for request_idx, pending_request in ou_pending_requests.iterrows():
            # create empty dict for rules keys and their corresponding values
            request_rating = dict()

            # iterate over enabled rules
            for rule in self.__rules:
                # call method for corresponding rule
                request_rating[rule["key"]] = getattr(self, rule["function"])(pending_request)
            
            #save request rating
            self.db.update_item(dict(sorted(request_rating.items())), request_idx, "Rating", self.db.absence_data)

    def get_top_priority_request(self, request):
        '''
            returns tuple of top priority request from all OU pending requests and one dataframe row of that request
        '''
        # get all rated OU pending requests
        pending_ou_requests = self.db.get_ou_absence_data(request, "Pending")

        # set indices by id to preserve sorting keys
        pending_ou_requests.set_index(keys="id", inplace=True)

        # create DF to easily sort them
        severities_df = pd.DataFrame((pending_ou_requests["Rating"]).apply(pd.Series), index=pending_ou_requests.index)

        # sort pending requests by predefined priorities in rules.json
        severities_df.sort_values(by=self.__rules_structs, ascending=self.__rules_df_sort, inplace=True)

        # get first request in sorted DF
        top_request = severities_df.iloc[0]
        top_request_absence_data = self.db.absence_data[self.db.absence_data['id'] == top_request.name]

        return top_request, top_request_absence_data.squeeze()



    def determine_top_priority_status(self, top_request):
        '''
            determine request status with checking if any rules are out of thresholds
            if everything is OK, status="Accepted" and resolution="OK"
        '''
        # default values if rules are OK
        request_status = "Accepted"
        status_resolution = "OK"
        
        # iterate over enabled rules
        for rule_rank in self.__rules_structs:

            #get rule threshold
            threshold = self.db.get_rule_threshold_by_key(rule_rank)

            #check if rule is not out of threshold and rule has any threshold
            if not pd.isnull(threshold) and \
                (
                    (top_request[rule_rank] == threshold and rule_rank != "D") 
                ## treshold has been reached and its not because of leave balance \
                or 
                ## treshold has been reached for time off leave balance
                    (top_request[rule_rank] == threshold and rule_rank == "D")
                ):
                    request_status = "Rejected"
                    status_resolution = self.db.get_rule_status_failed_resolution(rule_rank)
                    break

        return request_status, status_resolution


    def set_ou_requests_statuses(self, request):
        '''
            set status of first pending request of OU in wich parameter request is 
                based on priorities of rules in "rules_struct"
        '''
        # iterate over OU pending requests
        for _, pending_request in self.db.get_ou_absence_data(request, "Pending").iterrows():
            # rate all pending OU requests
            self.rating_function(pending_request)

            # get top priority request
            top_request, top_request_absence_data = self.get_top_priority_request(pending_request)

            # get top priority status to set
            status_to_set, status_resolution = self.determine_top_priority_status(top_request)

            # update request status and its resolution in absence_data DataFrame
            self.db.update_item(status_to_set, top_request_absence_data.name, "Status", self.db.absence_data)
            self.db.update_item(status_resolution, top_request_absence_data.name, "StatusResolution", self.db.absence_data)

            
            if status_to_set == "Rejected" and top_request_absence_data['AbsenceTypeCode'] == "TIM":
                # add employee leave balance if request rejected and its timeoff  
                new_leave_balance = self.db.get_employee_info(top_request_absence_data, "LeaveBalance") + self.db.get_request_leave_hours(top_request_absence_data)
                employee_idx = self.db.employees[self.db.employees['EmployeeID'] == top_request_absence_data['EmployeeID']].index
                self.db.update_item(new_leave_balance, employee_idx, "LeaveBalance", self.db.employees)
                self.db.update_item(new_leave_balance, employee_idx, "LeaveBalanceDisplay", self.db.employees)

    def absence_requests_handler(self):
        
        '''
            handle all pending requests until there is none left
        '''
        all_pending_requests = self.db.get_requests(status = "Pending")

        #set statuses to whole OU at time
        did_change = False
        while not all_pending_requests.empty:

            # start timer for updating duration of whole ratint
            start_time = time.time()

            # get sum of requests
            old_request_no = all_pending_requests.shape[0]

            # choose first pending request
            request = all_pending_requests.iloc[0]

            # get OUID of chosen request
            request_ouid = self.db.get_ouid_of_request(request)
            
            # set statuses for whole OU which "request" is from
            self.set_ou_requests_statuses(request)

            # get fresh data
            all_pending_requests = self.db.get_requests(status = "Pending")

            # get sum of request after setting statuses
            new_request_no = all_pending_requests.shape[0]

            # if nothing changed, break while loop to prevent infinite loop
            # safety measure
            if (old_request_no == new_request_no):
                did_change = False
                break
            
            # update duration of rating
            self.db.set_ou_rating_duration(request_ouid, start_time)
            print(self.db.absence_data)
            if not did_change:
                # set did_change only once
                did_change = True

        
        if did_change:
            self.db.update_db(self.db.absence_data, s3_key_website = 'OBJECT_NAME_ABSENCE')
            self.db.update_db(self.db.employees, s3_key_website = 'OBJECT_NAME_EMPLOYEES')
            self.db.update_db(self.db.teams, s3_key_website = 'OBJECT_NAME_TEAMS')
            response = {
            "statusCode": 200,
            "headers": {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
                },
            "body": json.dumps("done")
            }
            
            return response
        
        response = {
            "statusCode": 200,
            "headers": {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
                },
            "body": json.dumps("no change")
            }
            
        return response


def lambda_handler(event, context):
    
    
    s3_c = boto3.client('s3')
    
    s3_bucket_name = os.environ.get('BUCKET_NAME')
    s3_key_website_absence = os.environ.get('OBJECT_NAME_ABSENCE')
    s3_key_website_teams = os.environ.get('OBJECT_NAME_TEAMS')
    s3_key_website_employees = os.environ.get('OBJECT_NAME_EMPLOYEES')
    s3_key_website_jobs = os.environ.get('OBJECT_NAME_JOBS')
    s3_key_website_absence_type = os.environ.get('OBJECT_NAME_ABSENCE_TYPE')
    s3_key_website_rules = os.environ.get('OBJECT_NAME_RULES')
   
    
    s3_r = boto3.resource('s3')
    try:
        s3_r.Object(s3_bucket_name, s3_key_website_absence).load()
        s3_r.Object(s3_bucket_name, s3_key_website_teams).load()
        s3_r.Object(s3_bucket_name, s3_key_website_employees).load()
        s3_r.Object(s3_bucket_name, s3_key_website_jobs).load()
        s3_r.Object(s3_bucket_name, s3_key_website_absence_type).load()
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            print(f"File ({s3_key_website_absence})) required by this function does not exist!")
            return f"File ({s3_key_website_absence})) required by this function does not exist!"
        else:
            print(f"File ({s3_key_website_absence}) required by this function is not accessible!")
            return f"File ({s3_key_website_absence}) required by this function is not accessible!"
            
    try:
        path_absence_table = s3_r.Object(s3_bucket_name, s3_key_website_absence)
        path_teams_table = s3_r.Object(s3_bucket_name, s3_key_website_teams)
        path_employees_table = s3_r.Object(s3_bucket_name, s3_key_website_employees)
        path_jobs_table = s3_r.Object(s3_bucket_name, s3_key_website_jobs)
        path_absence_type_table = s3_r.Object(s3_bucket_name, s3_key_website_absence_type)
        path_rules_table = s3_r.Object(s3_bucket_name, s3_key_website_rules)
        global ars
        ars = ARS(s3_r, s3_c, path_absence_table, path_teams_table, path_employees_table, path_jobs_table, path_absence_type_table, path_rules_table)
        response =ars.absence_requests_handler()
        return response
    except botocore.exceptions.ClientError as e:
        return e
    