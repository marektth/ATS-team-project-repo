import json
import os
import time
from numpy import empty
import pandas as pd
import datetime
import boto3
import botocore
from botocore.exceptions import ClientError
from io import StringIO
from ARS import ARS




def lambda_handler(event, context):
    
    s3_c = boto3.client('s3')

    s3_bucket_name = os.environ.get('BUCKET_NAME')
    s3_key_website_absence = os.environ.get('OBJECT_NAME_ABSENCE')
    s3_key_website_teams = os.environ.get('OBJECT_NAME_TEAMS')
    s3_key_website_employees = os.environ.get('OBJECT_NAME_EMPLOYEES')
    s3_key_website_jobs = os.environ.get('OBJECT_NAME_JOBS')
    s3_key_website_absence_type = os.environ.get('OBJECT_NAME_ABSENCE_TYPE')
    
    s3_r = boto3.resource('s3')
    try:
        s3_r.Object(s3_bucket_name, s3_key_website_absence).load()
        s3_r.Object(s3_bucket_name, s3_key_website_teams).load()
        s3_r.Object(s3_bucket_name, s3_key_website_employees).load()
        s3_r.Object(s3_bucket_name, s3_key_website_jobs).load()
        s3_r.Object(s3_bucket_name, s3_key_website_absence_type).load()
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            print(f"File ({s3_key_website_absence})) required by this function does not exist!")
            return f"File ({s3_key_website_absence})) required by this function does not exist!"
        else:
            raise f"File ({s3_key_website_absence}) required by this function is not accessible!"
            print(f"File ({s3_key_website_absence}) required by this function is not accessible!")
            return f"File ({s3_key_website_absence}) required by this function is not accessible!"
        if e.response['Error']['Code'] == "404":
            print(f"File ({s3_key_website_teams})) required by this function does not exist!")
            return f"File ({s3_key_website_teams})) required by this function does not exist!"
        else:
            raise f"File ({s3_key_website_teams}) required by this function is not accessible!"
            print(f"File ({s3_key_website_teams}) required by this function is not accessible!")
            return f"File ({s3_key_website_teams}) required by this function is not accessible!"
        if e.response['Error']['Code'] == "404":
            print(f"File ({s3_key_website_employees})) required by this function does not exist!")
            return f"File ({s3_key_website_employees})) required by this function does not exist!"
        else:
            raise f"File ({s3_key_website_employees}) required by this function is not accessible!"
            print(f"File ({s3_key_website_employees}) required by this function is not accessible!")
            return f"File ({s3_key_website_employees}) required by this function is not accessible!"
        if e.response['Error']['Code'] == "404":
            print(f"File ({s3_key_website_jobs})) required by this function does not exist!")
            return f"File ({s3_key_website_jobs})) required by this function does not exist!"
        else:
            raise f"File ({s3_key_website_jobs}) required by this function is not accessible!"
            print(f"File ({s3_key_website_jobs}) required by this function is not accessible!")
            return f"File ({s3_key_website_jobs}) required by this function is not accessible!"
        if e.response['Error']['Code'] == "404":
            print(f"File ({s3_key_website_absence_type})) required by this function does not exist!")
            return f"File ({s3_key_website_absence_type})) required by this function does not exist!"
        else:
            raise f"File ({s3_key_website_absence_type}) required by this function is not accessible!"
            print(f"File ({s3_key_website_absence_type}) required by this function is not accessible!")
            return f"File ({s3_key_website_absence_type}) required by this function is not accessible!"
    
    
    
    try:
        path_absence_table = s3_r.Object(s3_bucket_name, s3_key_website_absence)
        path_teams_table = s3_r.Object(s3_bucket_name, s3_key_website_teams)
        path_employees_table = s3_r.Object(s3_bucket_name, s3_key_website_employees)
        path_jobs_table = s3_r.Object(s3_bucket_name, s3_key_website_jobs)
        path_absence_type_table = s3_r.Object(s3_bucket_name, s3_key_website_absence_type)
        
        ars = ARS(s3_r, s3_c, path_absence_table, path_teams_table, path_employees_table, path_jobs_table, path_absence_type_table)
        ars.absence_requests_handler()
        
    except botocore.exceptions.ClientError as e:
        return e
    